document.addEventListener('DOMContentLoaded', () => {
  const items = document.querySelectorAll('.product-item, .service-item');
  items.forEach(item => {
    item.addEventListener('click', () => {
      alert(`You selected: ${item.querySelector('h2').innerText}`);
    });
  });
});
